﻿namespace RepositorywithDI.Models.ViewModel
{
    /// <summary>
    /// AppSettings
    /// </summary>
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}
